package com.softwareSystemDemo.demo;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;




@Path("persons")
public class PersonResource 
{
	
	
	
	PersonRepository repo = new PersonRepository();
	
	@GET
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public List<Person> getPerson()
	{
		
		return repo.getPersons();
	}
	
	@GET
	@Path("getPerson/{rollNumber}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Person getPerson(@PathParam("rollNumber") int rollNumber)
	{
		return repo.getThatPerson(rollNumber);
	}
	
	@GET
	@Path("getPersonRange/{rollNumber1}/{rollNumber2}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public List<Person> getPersonRange(@PathParam("rollNumber1") int rollNumber1, @PathParam("rollNumber2") int rollNumber2)
	{
		return repo.getRangePerson(rollNumber1,rollNumber2);
	}
	
	
	@POST
	@Path("person")
	public Person createPerson(Person p) throws Exception
	{
		Person p1 = new Person();
		try{
			p1 = repo.createPerson(p);
		}
		catch(Exception e)
		{
			p1.setName(e.getMessage());
		}
		return p1;
	}
	@PUT
	@Path("updatePerson")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Person updatePerson(Person p)
	{
		Person p1 = repo.updatePerson(p);
		
		return p1;
	}
	@POST 
	@Path("/uploadStudentPic")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String ProductPicUpload(@FormDataParam("rollNumber") String roll,@FormDataParam("name") String name,@FormDataParam("physicsMarks") String physicsMarks,@FormDataParam("chemMarks") String chemMarks,@FormDataParam("mathsMarks") String mathsMarks,@FormDataParam("dob") String dob,
			@FormDataParam("file") InputStream fileInputStream,
			@FormDataParam("file") FormDataContentDisposition fileFormDataContentDisposition
			) throws Exception 
	{
		
		Integer rollNumber = Integer.parseInt(roll);
		Integer pmarks = Integer.parseInt(physicsMarks);
		Integer cmarks = Integer.parseInt(chemMarks);
		Integer mmarks = Integer.parseInt(mathsMarks);
		Person p = new Person();
		p.setRollNumber(rollNumber);
		p.setName(name);
		p.setPhysicsMarks(pmarks);
		p.setChemMarks(cmarks);
		p.setMathsMarks(mmarks);
		p.setDob(dob);
		try {
			repo.createPerson(p);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		String uploadFilePath = null;
		String fileName = fileFormDataContentDisposition.getFileName();
		if(fileName != null)
			uploadFilePath = repo.uploadStudentPic(fileInputStream, fileName, rollNumber);
		if (uploadFilePath == null)
			return null;

		return uploadFilePath;
	}	
}

