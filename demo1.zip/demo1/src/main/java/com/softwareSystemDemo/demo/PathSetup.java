package com.softwareSystemDemo.demo;

public class PathSetup {
	public static final String imagePath = "C:\\Users\\Dipta\\Downloads\\demo1\\src\\main\\webapp\\";
	//public static final String imagePath = "C:\\Users\\Dipta\\eclipse-workspace\\demo\\src\\main\\resources\\";

}
