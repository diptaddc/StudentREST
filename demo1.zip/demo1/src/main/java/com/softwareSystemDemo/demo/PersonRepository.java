package com.softwareSystemDemo.demo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;



public class PersonRepository 
{
	
	
	Connection con = null;
	
	public PersonRepository()
	{
		String url = "jdbc:mysql://localhost:3306/restdb";
		String username = "root";
		String password  = "admin123";
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, username, password);
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
	}
	
	public List<Person> getPersons()
	{
		List<Person> repository = new ArrayList<Person>();
		String sql = "select * from Person_Details";
		try
		{
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			{
				Person p = new Person();
				p.setRollNumber(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setPhysicsMarks(rs.getInt(3));
				p.setChemMarks(rs.getInt(4));
				p.setMathsMarks(rs.getInt(5));
				p.setDob(rs.getString(6));
				p.setPhoto_url(rs.getString(7));
				
				repository.add(p);
			}
			
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
		return repository;
	}
	
	public Person getThatPerson(int rollNumber)
	{
		
		String sql = "select * from Person_Details where rollNumber=" + rollNumber;
		Person p = new Person();
		try 
		{
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if(rs.next())
			{
				p.setRollNumber(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setPhysicsMarks(rs.getInt(3));
				p.setChemMarks(rs.getInt(4));
				p.setMathsMarks(rs.getInt(5));
				p.setDob(rs.getString(6));
				p.setPhoto_url(rs.getString(7));
			}
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
		return p;
	}
	public List<Person> getRangePerson(int rollNumber1, int rollNumber2)
	{
		
		String sql = "select * from Person_Details where rollNumber >= " + rollNumber1 +" and rollNumber<= " + rollNumber2;
		List<Person> list = new ArrayList<Person>();
		try 
		{
			
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			{
				Person p = new Person();
				p.setRollNumber(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setPhysicsMarks(rs.getInt(3));
				p.setChemMarks(rs.getInt(4));
				p.setMathsMarks(rs.getInt(5));
				p.setDob(rs.getString(6));
				p.setPhoto_url(rs.getString(7));
				
				list.add(p);
			}
			
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
		return list;
	}
	public Person createPerson(Person p) throws Exception 
	{
		String sql = "insert into Person_Details values(?,?,?,?,?,?,?)";
		try
		{
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, p.getRollNumber());
			st.setString(2, p.getName());
			st.setInt(3, p.getPhysicsMarks());
			st.setInt(4, p.getChemMarks());
			st.setInt(5, p.getMathsMarks());
			st.setString(6, p.getDob());
			st.setString(7,p.getPhoto_url());
			st.executeUpdate();
		}
		catch (Exception ex)
		{
			System.out.println(ex.getMessage());
			throw new Exception(ex.getMessage());
			
		}
		return p;
	}
	public Person updatePerson(Person p) 
	{
		String sql = "update Person_Details set name= ?,physicsMarks= ?,chemMarks= ?,mathsMarks= ?,dob= ? where rollNumber=?";
		try
		{
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(6, p.getRollNumber());
			st.setString(1, p.getName());
			st.setInt(2, p.getPhysicsMarks());
			st.setInt(3, p.getChemMarks());
			st.setInt(4, p.getMathsMarks());
			st.setString(5, p.getDob());
			st.executeUpdate();
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
		return p;
	}

	@SuppressWarnings("finally")
	public String uploadStudentPic(InputStream fileInputStream, String fileName, int rollNumber) {
		PreparedStatement preparedStatement3;
		File folder = new File(PathSetup.imagePath + "students/" + rollNumber);
		if(!folder.exists())
		{
			folder.mkdirs();
		}
		//File[] listOfFiles = folder.listFiles();
		//listOfFiles[0].delete();
		// System.out.println(userName+" "+listOfFiles[1].getName()+" profilepic to
		// delete");

		// System.out.println(f.delete());
		OutputStream outputStream = null;
		OutputStream outputStream1 = null;
		String path = PathSetup.imagePath + "students/" + rollNumber + "/";
		String personPicPath = PathSetup.imagePath + "students/" + rollNumber + "/";
		String databaseimagepath = "students/" + rollNumber + "/";
		Person product = new Person();
		try {
			outputStream = new FileOutputStream(new File(path + fileName));
			outputStream1 = new FileOutputStream(new File(personPicPath  + fileName));
			String query = "update Person_Details set photo_url = ? where rollNumber = ?";
			preparedStatement3 = con.prepareStatement(query);
			preparedStatement3.setString(1, databaseimagepath  + fileName);
			preparedStatement3.setInt(2, rollNumber);
			preparedStatement3.executeUpdate();
			int read = 0;
			byte[] bytes = new byte[1024];
			while ((read = fileInputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read);
				outputStream1.write(bytes, 0, read);
			}
			outputStream.close();
			outputStream1.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (outputStream != null) {
				product.setPhoto_url(personPicPath + fileName);
				return product.getPhoto_url();
			}
			return null;
		}
	}
}
