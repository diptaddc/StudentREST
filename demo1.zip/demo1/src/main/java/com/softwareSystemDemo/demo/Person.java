package com.softwareSystemDemo.demo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Person
{
	private int rollNumber;
	private String name;
	private String photo_url = "students/defaultProductPic.jpg";
	private int physicsMarks;
	private int chemMarks;
	private int mathsMarks;
	private String dob;
	
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPhoto_url() {
		return photo_url;
	}
	public int getPhysicsMarks() {
		return physicsMarks;
	}
	public void setPhysicsMarks(int physicsMarks) {
		this.physicsMarks = physicsMarks;
	}
	public int getChemMarks() {
		return chemMarks;
	}
	public void setChemMarks(int chemMarks) {
		this.chemMarks = chemMarks;
	}
	public int getMathsMarks() {
		return mathsMarks;
	}
	public void setMathsMarks(int mathsMarks) {
		this.mathsMarks = mathsMarks;
	}
	public void setPhoto_url(String photo_url) {
		this.photo_url = photo_url;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	
	
}
